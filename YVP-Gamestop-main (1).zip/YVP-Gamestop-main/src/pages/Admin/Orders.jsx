import React from "react";

function Orders() {
  return <div>Under DEVELOPMENT</div>;
}

export default Orders;
