import React from "react";

function OrderSuccess() {
  return <div>Order Shipped Successfully</div>;
}

export default OrderSuccess;
